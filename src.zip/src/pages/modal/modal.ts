import { Component } from '@angular/core';
import { IonicPage, ViewController, NavParams } from 'ionic-angular';
import { TIMEZONES } from './../../timezone_data/timezone.data'

@IonicPage()
@Component({
  selector: 'page-modal',
  templateUrl: 'modal.html',
})
export class ModalPage {
  searchQuery: string = '';
  timezones: any[];
  selectedZone: any;

  constructor(public viewCtrl: ViewController, private navParams: NavParams) {
    this.initializeItems();
  }
  closeModal() {
    this.viewCtrl.dismiss();
  }

  initializeItems() {
    this.timezones = TIMEZONES
  }

  onInput(ev: any) {
    this.initializeItems();
    let val = ev.target.value;
    if (val && val.trim() != '') {
      this.timezones = this.timezones.filter((timezone) => {
        if (timezone.value.toLowerCase().indexOf(val.toLowerCase()) > -1 
          || timezone.location.toLowerCase().indexOf(val.toLowerCase()) > -1) {
          return true;
         }
         return false;
      })
    }
  }

  selectedTimezone(timezone) {
    this.viewCtrl.dismiss({data:timezone});
  }
  // checkUtc(utc,val) {
  //   const filterUtc = utc.filter(element => element.toLowerCase().indexOf(val.toLowerCase()) > -1);
  //   console.log(filterUtc);
  //   return (filterUtc.length > 0) ? true : false;
  // }
}
